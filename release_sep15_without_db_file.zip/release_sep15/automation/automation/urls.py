from django.contrib import admin
from django.urls import path, include  # Import include to include app-level URLs

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('haystack.urls')),  # Include app-level URLs for 'haystack' app
    # Add other top-level URL patterns here if needed
]
