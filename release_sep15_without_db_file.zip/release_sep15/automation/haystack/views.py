import os
import rospy
import threading
import paramiko
import sqlite3
import datetime
import re
from django.shortcuts import render, HttpResponse, redirect
from django.contrib.auth import authenticate, login, logout
from django.http import HttpResponseRedirect
from .models import FilteredData, TempData 
from django.utils import timezone
from django.urls import reverse
from django.contrib import messages 

# Define global variables to store the IP address, Disinfect Auto Run data, and ROS Master URI
stored_ip = None
disinfect_data = {}
ros_master_uri = None
DEFAULT_USERNAME = "haystack"
DEFAULT_PASSWORD = "haystack"
REMOTE_DB_PATH = "/haystack_disinfect_report/database/disinfect_status_report.db"
LOCAL_DB_PATH = "/tmp/disinfect_status_report.db"

def change_mode_to_disinfect():
    rospy.set_param('/haystack/mode', 'DISINFECT')

def change_mode_to_idle():
    rospy.set_param('/haystack/mode', 'IDLE')

def run_ros_node():
    rospy.init_node('disinfection_node', anonymous=True)
    rospy.spin()

def connect_to_device(ip):
    global stored_ip

    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(stored_ip, username=DEFAULT_USERNAME, password=DEFAULT_PASSWORD)

        with ssh_client.open_sftp() as sftp:
            sftp.get(REMOTE_DB_PATH, LOCAL_DB_PATH)

        conn = sqlite3.connect(LOCAL_DB_PATH)
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        table_names = [row[0] for row in cursor.fetchall()]

        conn.close()
        ssh_client.close()

        return table_names
    except Exception as e:
        return str(e)

def get_table_data(ip, table_name="HAYSTACK_DISINFECT_REPORT"):
    try:
        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(ip, username=DEFAULT_USERNAME, password=DEFAULT_PASSWORD)

        with ssh_client.open_sftp() as sftp:
            sftp.get(REMOTE_DB_PATH, LOCAL_DB_PATH)

        conn = sqlite3.connect(LOCAL_DB_PATH)
        cursor = conn.cursor()
        cursor.execute(f"PRAGMA table_info({table_name});")
        columns = [row[1] for row in cursor.fetchall()]

        cursor.execute(f"SELECT * FROM {table_name};")
        rows = cursor.fetchall()

        conn.close()
        ssh_client.close()

        return columns, rows
    except Exception as e:
        return str(e)

def new_model_template(request):
    if request.method == 'POST':
        ip = request.POST.get('ip')
        table_name = request.POST.get('table_name')
        table_names = connect_to_device(ip)
        columns = []
        table_data = []
        non_filtered_data = []

        if table_name:
            columns, table_data = get_table_data(ip, table_name)

        # Date filter
        today = datetime.date.today()
        today_date = today.strftime("%Y_%-m_%-d")

        filtered_data = []
        for row in table_data:
            if row[10] == today_date:
                filtered_data.append(row)
            non_filtered_data.append(row)

        filtered_data_from_db = FilteredData.objects.all()

        return render(request, 'new_model_report.html', {'table_names': table_names, 'columns': columns, 'table_data': filtered_data, 'filtered_data': filtered_data_from_db, 'non_filtered_data': non_filtered_data})
    else:
        return render(request, 'new_model_report.html')

def home(request):
    global stored_ip
    global disinfect_data
    global ros_master_uri
    filtered_data = FilteredData.objects.all()
    filtered_data_from_db = FilteredData.objects.all()
    temp_data = TempData.objects.all()

    #check if logging in or not
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        #auth
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "welcome to haystack!")
            # Get the ROS_MASTER_URI from the form submission
            return redirect('home')
        else: 
            messages.success(request, "there was an error logging in, please try again latter...!")
            return redirect('home')
    # else:

    elif request.method == 'POST':
        stored_ip = request.POST.get('ip_address')
        ros_master_uri = f'http://{stored_ip}:11311'

    return render(request, 'home.html', {'stored_ip': stored_ip, 'disinfect_data': disinfect_data, 'ros_master_uri': ros_master_uri, 'filtered_data': filtered_data, 'temp_data': temp_data})

def store_ip(request):
    global stored_ip
    global ros_master_uri
    if request.method == 'POST':
        stored_ip = request.POST.get('ip_address')
        ros_master_uri = f'http://{stored_ip}:11311'

    return HttpResponseRedirect(reverse('home'))

def filter_and_save_data(ip, table_name):
    # Date filter
    today = datetime.date.today()
    today_date = today.strftime("%Y_%-m_%-d")
    columns, table_data = get_table_data(ip, table_name)
    last_data_row = table_data[-1]
    existing_row = FilteredData.objects.filter(id=last_data_row[0]).first()
    if not existing_row:
        filtered_row = FilteredData(
            id=last_data_row[0],
            year=last_data_row[1],
            month=last_data_row[2],
            day=last_data_row[3],
            hour=last_data_row[4],
            min=last_data_row[5],
            room=last_data_row[6],
            percentage=last_data_row[7],
            duration=last_data_row[8],
            image=last_data_row[9],
            date=last_data_row[10],
            status=last_data_row[11],
            ip_address=ip,
            created_at=timezone.now(),
        )
        filtered_row.save()
    filtered_data = [last_data_row] if last_data_row[10] == today_date else []

    # Save the data to the 'temp' table
    temp_row = TempData(
        year=last_data_row[1],
        month=last_data_row[2],
        day=last_data_row[3],
        hour=last_data_row[4],
        min=last_data_row[5],
        room=last_data_row[6],
        percentage=last_data_row[7],
        duration=last_data_row[8],
        image=last_data_row[9],
        date=last_data_row[10],
        status=last_data_row[11],
        ip_address=ip,
        created_at=timezone.now(),
    )
    temp_row.save()

def display_filtered_data(request):
    filtered_data = FilteredData.objects.all()
    return render(request, 'filtered_data.html', {'filtered_data': filtered_data})

def temp_data(request):
    # Retrieve data from the 'temp' table
    temp_data = TempData.objects.all()
    return render(request, 'temp_data.html', {'temp_data': temp_data})

def reset_temp_table(request):
    TempData.objects.all().delete()
    return HttpResponseRedirect(reverse('home'))


def disinfect_auto_run(request):
    global disinfect_data
    global ros_master_uri
    global stored_ip

    if request.method == 'POST':
        # Clear the TempData table
        TempData.objects.all().delete()

        no_of_runs = request.POST.get('no_of_runs')
        room_no = request.POST.get('room_no')
        setup_no = request.POST.get('setup_no')
        disinfect_data = {
            'no_of_runs': no_of_runs,
            'room_no': room_no,
            'setup_no': setup_no,
        }

        # Set ROS_MASTER_URI and ROS_IP environment variables
        os.environ['ROS_MASTER_URI'] = ros_master_uri
        os.environ['ROS_IP'] = '172.16.2.66'

        # Calculate the timestamp
        # timestamp_variable = timezone.now()

        ros_thread = threading.Thread(target=run_ros_node)
        ros_thread.start()
        input_number = int(room_no)
        table_name = "HAYSTACK_DISINFECT_REPORT"

        if request.method == 'POST':
            try:
                num_runs = int(no_of_runs)
                room_setup_number = int(setup_no)
                table_name = "HAYSTACK_DISINFECT_REPORT"

                if num_runs <= 0:
                    return HttpResponse("Error: Invalid number of runs.")

                run = 0
                starting = 0 

                while run < num_runs - 1:

                    mode = rospy.get_param('/haystack/mode', default='IDLE')
                    

                    if mode == 'IDLE':
                        rospy.loginfo("Mode is IDLE. Waiting for 10 seconds...")
                        rospy.sleep(duration=10.0)
                        rospy.set_param('/disinfect_room_number', input_number)
                        change_mode_to_disinfect()
                        rospy.loginfo("Mode changed to DISINFECT.")
                        rospy.sleep(duration=10.0)
                        
                        if starting: 
                            run += 1
                        starting = 1
                    # rospy.sleep(duration=10.0)
                    # mode = rospy.get_param('/haystack/mode', default='IDLE')
                    if run !=0 and mode == 'IDLE':
                        filter_and_save_data(stored_ip, table_name)
                        

                        # if table_name:
                        #     filter_and_save_data(stored_ip, table_name)

                        print("Run Count:", run)

                    else:
                        rospy.loginfo("Mode is not IDLE. Waiting for 5 seconds...")
                        rospy.sleep(duration=5.0)

                rospy.loginfo("All runs completed. Mode changed back to IDLE.")

                mode1 = rospy.get_param('/haystack/mode', default='IDLE')
                while mode1 != 'IDLE':
                    rospy.sleep(duration=5.0)
                    mode1 = rospy.get_param('/haystack/mode', default='IDLE')
                if run != 0 and table_name: 
                    rospy.sleep(duration=5.0)
                    filter_and_save_data(stored_ip, table_name)

                # return HttpResponse("Last Run !!!.")
            except Exception as e:
                return HttpResponse(f"Error: {e}")

    return HttpResponseRedirect(reverse('home'))

def about(request):
    return render(request, 'about.html')


def logout_user(request):
    logout(request)
    messages.success(request, "Sucessfully loged out...")
    return redirect('home')