from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('store_ip/', views.store_ip, name='store_ip'),
    path('disinfect_auto_run/', views.disinfect_auto_run, name='disinfect_auto_run'),
    path('display-database/', views.new_model_template, name='display_database'),
    path('filtered-data/', views.display_filtered_data, name='display_filtered_data'),
    path('temp-data/', views.temp_data, name='temp_data'),
    path('logout/', views.logout_user, name = 'logout'),
    # path('toggle-disinfect-container/', views.toggle_disinfect_container, name='toggle_disinfect_container'),
    

    # Add more URL patterns as needed
]
